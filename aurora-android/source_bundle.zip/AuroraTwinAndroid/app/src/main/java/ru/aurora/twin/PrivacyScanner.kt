package ru.aurora.twin

/** A deliberately conservative, offline demonstrator, NOT a production-grade DLP system. */
data class PrivacyReport(
    val scannedCharacters: Int,
    val masked: Map<String, Int>,
    val sanitizedPreview: String,
    val warnings: List<String>,
    val sampleMessages: Int
) {
    val total: Int get() = masked.values.sum()
}

object PrivacyScanner {
    private val email = Regex("\\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}\\b", RegexOption.IGNORE_CASE)
    private val phone = Regex("(?<!\\w)(?:\\+?7|8)[\\s()\\-]*\\d{3}[\\s()\\-]*\\d{3}[\\s\\-]*\\d{2}[\\s\\-]*\\d{2}(?!\\w)")
    private val password = Regex("(?im)(?:(?:password|пароль|passcode|секретный\\s+код)\\s*[:=]\\s*)([^\\s,;]+)")
    private val otp = Regex("(?im)(?:код\\s*(?:из\\s*смс|подтверждения|входа)|otp|verification\\s*code)\\s*[:=]?\\s*(\\d{4,8})")
    private val cardCandidate = Regex("(?<!\\d)(?:\\d[\\s-]?){13,19}(?!\\d)")
    private val topic = Regex("(?i)\\b(?:диагноз|болезн|лечение|беременност|интимн|паспорт|реб[её]нок|дет(?:и|ей)|медицинск)\\w*")

    fun scan(text: String): PrivacyReport {
        val counters = mutableMapOf<String, Int>()
        fun count(key: String) { counters[key] = (counters[key] ?: 0) + 1 }
        // Highly sensitive topic lines are excluded rather than 'summarized'.
        val lines = text.lines().map { line ->
            if (topic.containsMatchIn(line)) {
                count("Чувствительные темы")
                "[ТЕМА ИСКЛЮЧЕНА]"
            } else line
        }
        var safe = lines.joinToString("\n")
        safe = password.replace(safe) { m -> count("Пароли"); m.value.replace(m.groupValues[1], "[ПАРОЛЬ]") }
        safe = otp.replace(safe) { m -> count("Коды входа"); m.value.replace(m.groupValues[1], "[КОД]") }
        safe = email.replace(safe) { count("Email"); "[EMAIL]" }
        safe = phone.replace(safe) { count("Телефоны"); "[ТЕЛЕФОН]" }
        safe = cardCandidate.replace(safe) { m ->
            val digits = m.value.filter { it.isDigit() }
            if (digits.length in 13..19 && luhn(digits)) { count("Банковские карты"); "[КАРТА]" } else m.value
        }
        return PrivacyReport(text.length, counters.toMap(), safe.take(1400),
            listOf("Локальная демонстрационная проверка не гарантирует выявление всех секретов.",
                "Оригинал не сохраняется и не отправляется на сервер."),
            text.count { it == '\n' } + 1)
    }

    fun luhn(digits: String): Boolean {
        if (digits.length !in 13..19 || !digits.all(Char::isDigit)) return false
        var sum = 0
        var double = false
        for (c in digits.reversed()) {
            var n = c.digitToInt()
            if (double) { n *= 2; if (n > 9) n -= 9 }
            sum += n
            double = !double
        }
        return sum % 10 == 0
    }
}
