package ru.aurora.twin

import android.content.Context
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import kotlin.math.*

object Aura {
    val base = Color(0xFF0B1020)
    val deep = Color(0xFF080C18)
    val surface = Color(0xFF151D31)
    val raised = Color(0xFF1D2941)
    val border = Color(0xFF34415A)
    val white = Color(0xFFF5F8FF)
    val secondary = Color(0xFFB8C4DA)
    val muted = Color(0xFF8F9EB9)
    val mint = Color(0xFF4DDCC8)
    val violet = Color(0xFFA994F5)
    val cyan = Color(0xFF70C8F7)
    val green = Color(0xFF6DE2AD)
    val orange = Color(0xFFFFCF75)
    val red = Color(0xFFFF8B9A)
}

@Composable fun AuroraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = Aura.mint, onPrimary = Aura.deep,
            secondary = Aura.violet, background = Aura.base, surface = Aura.surface,
            onBackground = Aura.white, onSurface = Aura.white, error = Aura.red),
        typography = Typography(), content = content
    )
}

fun motionAllowed(context: Context, userEnabled: Boolean): Boolean {
    if (!userEnabled) return false
    val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    if (pm?.isPowerSaveMode == true) return false
    return try { Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) > 0f }
    catch (_: Exception) { true }
}

/** Deterministic particles: no bitmap/video, and animation shuts off in power-saver. */
@Composable fun AuroraParticles(modifier: Modifier = Modifier, enabled: Boolean = true) {
    val ctx = LocalContext.current
    val animated = remember(enabled) { motionAllowed(ctx, enabled) }
    val time = if (animated) {
        val transition = rememberInfiniteTransition(label = "aura-field")
        val fraction by transition.animateFloat(
            initialValue = 0f, targetValue = 2f * PI.toFloat(),
            animationSpec = infiniteRepeatable(tween(22000, easing = LinearEasing), RepeatMode.Restart),
            label = "particles")
        fraction
    } else 0f
    Canvas(modifier) {
        val w = size.width; val h = size.height
        if (w <= 0f || h <= 0f) return@Canvas
        drawRect(brush = Brush.radialGradient(
            0f to Aura.violet.copy(alpha = .16f),
            .48f to Aura.cyan.copy(alpha = .07f), 1f to Color.Transparent,
            center = Offset(w * .78f, h * .27f), radius = w * .85f))
        val points = List(35) { i ->
            val xf = ((i * 53 + 19) % 97) / 97f
            val yf = ((i * 29 + 7) % 89) / 89f
            val shift = if (animated) sin(time * .65f + i * .6f) * 7.dp.toPx() else 0f
            Offset(xf * w + shift, yf * h + if (animated) cos(time + i) * 4.dp.toPx() else 0f)
        }
        points.forEachIndexed { i, p ->
            val c = if (i % 3 == 0) Aura.violet else Aura.mint
            drawCircle(c.copy(alpha = .25f + (i % 4) * .07f),
                radius = (0.7f + i % 3 * .35f).dp.toPx(), center = p)
            if (i < 30 && i % 2 == 0) {
                val q = points[(i + 7) % points.size]
                if ((p - q).getDistance() < w * .34f)
                    drawLine(Aura.cyan.copy(alpha = .12f), p, q, strokeWidth = .7.dp.toPx())
            }
        }
    }
}

@Composable fun AuroraHero(modifier: Modifier = Modifier, height: Dp = 220.dp, animate: Boolean = true) {
    Box(modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(24.dp))
        .background(Brush.linearGradient(listOf(Aura.deep, Color(0xFF18203F), Aura.deep)))) {
        AuroraParticles(Modifier.fillMaxSize(), enabled = animate)
        Image(painterResource(R.drawable.twin_hero), contentDescription = "Два связанных силуэта — символ цифрового двойника",
            modifier = Modifier.fillMaxSize().padding(4.dp), contentScale = androidx.compose.ui.layout.ContentScale.Fit)
    }
}

@Composable fun TwinBadge(modifier: Modifier = Modifier, size: Dp = 42.dp) {
    Image(painter = painterResource(R.drawable.twin_icon), contentDescription = "Двойник",
        modifier = modifier.size(size).clip(RoundedCornerShape(12.dp)))
}

@Composable fun AuroraCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxWidth().clip(RoundedCornerShape(19.dp))
        .background(Aura.surface).border(1.dp, Aura.border.copy(alpha = .58f), RoundedCornerShape(19.dp))
        .padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
}

@Composable fun MainButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Button(onClick = onClick, modifier = modifier.fillMaxWidth().heightIn(min = 54.dp), enabled = enabled,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Aura.mint, contentColor = Aura.deep,
            disabledContainerColor = Aura.raised, disabledContentColor = Aura.muted)) {
        Text(text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}

@Composable fun OutlineButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    OutlinedButton(onClick = onClick, modifier = modifier.fillMaxWidth().heightIn(min = 52.dp),
        shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Aura.border)) {
        Text(text, color = Aura.white)
    }
}

@Composable fun Headline(heading: String, description: String? = null) {
    Text(heading, fontWeight = FontWeight.Bold, fontSize = 25.sp, color = Aura.white, lineHeight = 31.sp)
    if (description != null) Text(description, color = Aura.secondary, fontSize = 14.sp, lineHeight = 21.sp)
}

@Composable fun TextTag(label: String, color: Color = Aura.cyan) {
    Text(label, color = color, fontSize = 11.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = .12f))
            .padding(horizontal = 9.dp, vertical = 5.dp))
}

@Composable fun SectionHeading(title: String, action: String? = null, onClick: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Aura.white)
        if (action != null && onClick != null) TextButton(onClick = onClick) { Text(action, color = Aura.mint) }
    }
}
