package ru.aurora.twin

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

/** UI-only prototype. No INTERNET permission; the Telegram and AI screens are local demos. */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(11, 16, 32)
        window.navigationBarColor = android.graphics.Color.rgb(11, 16, 32)
        setContent { AuroraTheme { TwinApp() } }
    }
}

private enum class Page {
    WELCOME, METHOD, QUICK, BOUNDARIES, UPLOAD, PRIVACY_REPORT, ASSEMBLING,
    HOME, DIALOGS, PERSONA, REVIEW, TEST_CHAT, TELEGRAM, MEMORY, SETTINGS, CONTACT
}

private data class DemoChat(val name: String, val snippet: String, val state: String, val time: String)
private val chats = listOf(
    DemoChat("Алексей", "Может, встретимся в выходные?", "Нужно решение", "12:14"),
    DemoChat("Максим", "Как относишься к путешествиям?", "Отвечает двойник", "11:47"),
    DemoChat("Кирилл", "Привет! Чем занимаешься?", "Ожидает", "10:26"),
    DemoChat("Анна", "Давай созвонимся завтра", "Нужно решение", "Вчера")
)

@Composable
private fun TwinApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var page by rememberSaveable { mutableStateOf(Page.WELCOME) }
    var lastPage by rememberSaveable { mutableStateOf(Page.HOME) }
    var created by rememberSaveable { mutableStateOf(false) }
    var autopilot by rememberSaveable { mutableStateOf(false) }
    var movement by rememberSaveable { mutableStateOf(true) }
    var role by rememberSaveable { mutableStateOf("Личное общение") }
    var voice by rememberSaveable { mutableStateOf("Дружелюбная") }
    var humor by rememberSaveable { mutableStateOf("С лёгким юмором") }
    var boundaries by rememberSaveable { mutableStateOf("Не делиться номером, не обещать встречи, не обсуждать деньги") }
    var selfIntro by rememberSaveable { mutableStateOf("Люблю общение по делу, лёгкий юмор и уважение к моему времени") }
    var testInput by rememberSaveable { mutableStateOf("") }
    var testReply by rememberSaveable { mutableStateOf("Привет! Расскажи немного о себе 🙂") }
    var proposal by rememberSaveable { mutableStateOf("Звучит интересно! Давай сначала немного пообщаемся здесь 🙂") }
    var reviewState by rememberSaveable { mutableStateOf("Ожидает решения") }
    var importedName by rememberSaveable { mutableStateOf("") }
    var report by remember { mutableStateOf<PrivacyReport?>(null) }
    var importError by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var activeChat by rememberSaveable { mutableStateOf("Алексей") }
    var editProposal by rememberSaveable { mutableStateOf(false) }
    val loader = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            loading = true
            importError = ""
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val stream = context.contentResolver.openInputStream(uri)
                            ?: error("Файл не удалось открыть")
                        val text = stream.use { input ->
                            val bytes = ByteArrayOutputStream()
                            val part = ByteArray(8192)
                            var total = 0
                            while (true) {
                                val n = input.read(part)
                                if (n < 0) break
                                total += n
                                require(total <= 2_000_000) { "Для демо выбери файл до 2 МБ" }
                                bytes.write(part, 0, n)
                            }
                            bytes.toString(Charsets.UTF_8.name())
                        }
                        PrivacyScanner.scan(text)
                    }
                }
                loading = false
                result.onSuccess {
                    report = it
                    importedName = "Локальный файл"
                    page = Page.PRIVACY_REPORT
                }.onFailure { importError = it.message ?: "Не удалось прочитать файл" }
            }
        }
    }
    fun go(next: Page) { if (next != page) { lastPage = page; page = next } }
    BackHandler(enabled = page != Page.WELCOME && page != Page.HOME) {
        page = when (page) {
            Page.METHOD -> Page.WELCOME
            Page.QUICK, Page.UPLOAD -> Page.METHOD
            Page.BOUNDARIES -> Page.QUICK
            Page.PRIVACY_REPORT -> Page.UPLOAD
            Page.ASSEMBLING -> Page.METHOD
            else -> Page.HOME
        }
    }
    Column(Modifier.fillMaxSize().background(Aura.base)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            if (page != Page.WELCOME && page != Page.HOME) {
                IconButton(onClick = { page = if (page == Page.QUICK || page == Page.UPLOAD) Page.METHOD else Page.HOME }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад", tint = Aura.white)
                }
            } else { TwinBadge(size = 34.dp) }
            Spacer(Modifier.width(8.dp))
            Text(if (page == Page.WELCOME || page == Page.HOME) "Двойник" else when (page) {
                Page.METHOD -> "Создание двойника"; Page.QUICK -> "Быстрый старт"
                Page.BOUNDARIES -> "Мои правила"; Page.UPLOAD -> "Импорт переписки"
                Page.PRIVACY_REPORT -> "Защита данных"; Page.ASSEMBLING -> "Создание личности"
                Page.DIALOGS -> "Диалоги"; Page.PERSONA -> "Мой двойник"
                Page.REVIEW -> "Нужно твоё решение"; Page.TEST_CHAT -> "Проверить двойника"
                Page.TELEGRAM -> "Telegram Business"; Page.MEMORY -> "Память"
                Page.SETTINGS -> "Настройки"; Page.CONTACT -> activeChat; Page.WELCOME, Page.HOME -> "Двойник"
            }, color = Aura.white, fontWeight = FontWeight.SemiBold, fontSize = 18.sp,
                modifier = Modifier.weight(1f))
            TextTag("ДЕМО", Aura.violet)
        }
        Box(Modifier.weight(1f)) {
            AuroraParticles(Modifier.fillMaxSize(), enabled = movement)
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
                when (page) {
                    Page.WELCOME -> {
                        Spacer(Modifier.height(8.dp))
                        AuroraHero(height = 245.dp, animate = movement)
                        Headline("Твой цифровой двойник", "Отвечает в твоём стиле, пока ты занимаешься своей жизнью.")
                        Text("Не заменяет тебя. Берёт на себя рутину и передаёт важное.", color = Aura.secondary)
                        MainButton("Создать двойника", { go(Page.METHOD) })
                        OutlineButton("Посмотреть демо", { created = true; go(Page.HOME) })
                        Footnote("Telegram в прототипе не подключён. Все примеры вымышлены.")
                    }
                    Page.METHOD -> {
                        AuroraHero(height = 170.dp, animate = movement)
                        Headline("Как создадим твоего двойника?", "Выбирай удобный способ. Его можно улучшать в любой момент.")
                        ChoiceCard("Быстрый старт", "Пара минут, без загрузки переписок", "✦") { go(Page.QUICK) }
                        ChoiceCard("По моим сообщениям", "Проверим и очистим данные до импорта", "◈") { go(Page.UPLOAD) }
                        Footnote("Оба способа создают редактируемый профиль. Без переписок сходство с твоей реальной речью будет приблизительным.")
                    }
                    Page.QUICK -> {
                        Headline("Какая ты в переписке?", "Здесь нет правильных ответов — выбери то, что тебе близко.")
                        SectionHeading("Для чего нужен двойник?")
                        PillRow(listOf("Личное общение", "Блог и подписчики", "Рабочие запросы"), role) { role = it }
                        SectionHeading("Манера общения")
                        PillRow(listOf("Дружелюбная", "Сдержанная", "Уверенная"), voice) { voice = it }
                        SectionHeading("Юмор")
                        PillRow(listOf("С лёгким юмором", "Без шуток", "Иронично"), humor) { humor = it }
                        AuroraCard {
                            Text("В двух словах о себе", fontWeight = FontWeight.SemiBold)
                            AuroraInput(selfIntro, { selfIntro = it }, "Что важно в твоём общении?")
                        }
                        MainButton("Дальше — мои границы", { go(Page.BOUNDARIES) })
                    }
                    Page.BOUNDARIES -> {
                        Headline("Что двойнику нельзя?", "Эти правила важнее манеры общения. Их можно изменить позже.")
                        AuroraCard {
                            Text("Мои ограничения", fontWeight = FontWeight.SemiBold)
                            AuroraInput(boundaries, { boundaries = it }, "Например: не давать мой номер", lines = 4)
                        }
                        listOf("Не обещать встречи без меня", "Не передавать контакты и адрес", "Не обсуждать деньги и интимные темы")
                            .forEach { Text("✓ $it", color = Aura.secondary, fontSize = 14.sp) }
                        MainButton("Создать стартового двойника", { created = true; go(Page.ASSEMBLING) })
                    }
                    Page.UPLOAD -> {
                        Headline("Загрузи переписки", "На этом этапе файл обрабатывается только на твоём устройстве.")
                        AuroraCard {
                            Text("JSON или TXT · до 2 МБ", fontWeight = FontWeight.SemiBold)
                            Text("В демонстрации проверяем текст на телефоны, банковские карты, e-mail, пароли и некоторые чувствительные темы. Вложения не обрабатываются.", color = Aura.secondary, fontSize = 13.sp)
                            MainButton(if (loading) "Проверяем файл…" else "Выбрать файл", {
                                loader.launch(arrayOf("application/json", "text/plain", "*/*"))
                            }, enabled = !loading)
                        }
                        if (importError.isNotBlank()) Text(importError, color = Aura.red)
                        Footnote("Важно: автоматическая проверка не даёт абсолютной гарантии. Демо не сохраняет оригинал и не отправляет его в сеть.")
                        OutlineButton("Лучше без загрузки", { go(Page.QUICK) })
                    }
                    Page.PRIVACY_REPORT -> {
                        Headline("Сначала — безопасность", "Найдены фрагменты, которые не должны попадать в модель без проверки.")
                        AuroraCard {
                            Text("Проверено символов: ${report?.scannedCharacters ?: 0}")
                            Text("Обнаружено фрагментов: ${report?.total ?: 0}", color = Aura.mint, fontWeight = FontWeight.Bold)
                            report?.masked?.forEach { (kind, count) -> Text("• $kind: $count", color = Aura.secondary) }
                        }
                        AuroraCard {
                            Text("Предпросмотр после очистки", fontWeight = FontWeight.SemiBold)
                            Text(report?.sanitizedPreview.orEmpty().take(500), color = Aura.secondary, fontSize = 12.sp)
                        }
                        Footnote("Это демонстрация локальной маскировки. Для настоящего импорта потребуется усиленная проверка и отдельное согласие.")
                        MainButton("Продолжить с очищенным текстом", { created = true; go(Page.ASSEMBLING) })
                        OutlineButton("Выбрать другой файл", { go(Page.UPLOAD) })
                    }
                    Page.ASSEMBLING -> {
                        AuroraHero(height = 230.dp, animate = movement)
                        Headline("Первый двойник готов", "Это демо-профиль. Настоящее обучение ИИ будет подключено через твой существующий движок.")
                        AuroraCard {
                            Text("Характер: $voice", color = Aura.white)
                            Text("Юмор: $humor", color = Aura.secondary)
                            Text("Назначение: $role", color = Aura.secondary)
                        }
                        MainButton("Познакомиться с двойником", { go(Page.TEST_CHAT) })
                        OutlineButton("На главный экран", { go(Page.HOME) })
                    }
                    Page.HOME -> {
                        Spacer(Modifier.height(3.dp))
                        AuroraHero(height = 204.dp, animate = movement)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Headline(if (created) "Двойник на связи" else "Твой двойник ждёт тебя", "Твоя личность. Твои правила. Твой контроль.")
                            }
                            TextTag(if (autopilot) "АКТИВЕН" else "ПАУЗА", if (autopilot) Aura.green else Aura.orange)
                        }
                        AuroraCard {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("Автопилот", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                                    Text(if (autopilot) "Демо-режим включён" else "Остановлен", color = Aura.secondary, fontSize = 13.sp)
                                }
                                Switch(autopilot, { autopilot = it }, colors = SwitchDefaults.colors(checkedThumbColor = Aura.deep, checkedTrackColor = Aura.mint))
                            }
                            Footnote("В демонстрации переключатель ничего не отправляет в Telegram.")
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MiniMetric("12", "Диалогов", Modifier.weight(1f))
                            MiniMetric("3", "На проверку", Modifier.weight(1f))
                            MiniMetric("6", "Черновиков", Modifier.weight(1f))
                        }
                        SectionHeading("Нужно твоё внимание", "Все") { go(Page.DIALOGS) }
                        chats.take(2).forEach { item -> ChatItem(item) { activeChat = item.name; go(Page.REVIEW) } }
                        ChoiceCard("Подключить Telegram", "Посмотреть официальный путь подключения", "✈") { go(Page.TELEGRAM) }
                    }
                    Page.DIALOGS -> {
                        Headline("Все переписки", "Двойник подготовил ответы. Ты решаешь, что отправлять.")
                        chats.forEach { item -> ChatItem(item) { activeChat = item.name; go(Page.CONTACT) } }
                        Footnote("Тестовые диалоги. Нет доступа к реальным сообщениям.")
                    }
                    Page.PERSONA -> {
                        AuroraHero(height = 172.dp, animate = movement)
                        Headline("Мой цифровой характер", "Меняй в любой момент. Новые правила применятся в следующих ответах.")
                        AuroraCard {
                            Text("Моя манера", fontWeight = FontWeight.SemiBold)
                            PillRow(listOf("Дружелюбная", "Сдержанная", "Уверенная"), voice) { voice = it }
                            PillRow(listOf("С лёгким юмором", "Без шуток", "Иронично"), humor) { humor = it }
                        }
                        AuroraCard {
                            Text("Как я говорю о себе", fontWeight = FontWeight.SemiBold)
                            AuroraInput(selfIntro, { selfIntro = it }, "Расскажи о себе", lines = 3)
                        }
                        AuroraCard {
                            Text("Мои границы", fontWeight = FontWeight.SemiBold)
                            AuroraInput(boundaries, { boundaries = it }, "Что нельзя говорить", lines = 3)
                        }
                        MainButton("Проверить в тестовом чате", { go(Page.TEST_CHAT) })
                        ChoiceCard("Память и контекст", "Что двойник может помнить", "◈") { go(Page.MEMORY) }
                    }
                    Page.REVIEW -> {
                        Headline("Нужно твоё решение", "Двойник не отправит этот ответ без твоего подтверждения.")
                        AuroraCard {
                            Text("$activeChat · Telegram (демо)", fontWeight = FontWeight.Bold)
                            Text("Может, встретимся в выходные?", color = Aura.secondary)
                            HorizontalDivider(color = Aura.border)
                            Text("Предложение двойника", color = Aura.mint)
                            if (editProposal) AuroraInput(proposal, { proposal = it }, "Исправь ответ", lines = 3)
                            else Text(proposal, fontSize = 16.sp)
                        }
                        TextTag(reviewState, if (reviewState == "Отправлено в демо") Aura.green else Aura.orange)
                        MainButton(if (editProposal) "Сохранить изменение" else "Одобрить в демо", {
                            if (editProposal) { editProposal = false; reviewState = "Изменено" }
                            else reviewState = "Отправлено в демо"
                        })
                        OutlineButton(if (editProposal) "Отмена" else "Исправить ответ", { editProposal = !editProposal })
                        OutlineButton("Взять разговор на себя", { reviewState = "Передано владельцу"; go(Page.CONTACT) })
                        Footnote("В демо кнопка «Одобрить» не отправляет сообщения в Telegram.")
                    }
                    Page.TEST_CHAT -> {
                        Headline("Поговори с двойником", "Проверь, как он отвечает. Всё пока локально и на примерах.")
                        AuroraCard {
                            Text("Ты", color = Aura.cyan, fontWeight = FontWeight.SemiBold)
                            Text(if (testInput.isBlank()) "Привет! Давай познакомимся?" else testInput)
                        }
                        AuroraCard {
                            Text("Твой двойник", color = Aura.violet, fontWeight = FontWeight.SemiBold)
                            Text(testReply)
                            Footnote("Шаблонный ответ для проверки интерфейса, не результат работы ИИ.")
                        }
                        AuroraInput(testInput, { testInput = it }, "Напиши сообщение", lines = 2)
                        MainButton("Показать пример ответа", {
                            testReply = when {
                                testInput.contains("встр", ignoreCase = true) -> "Не спеши 🙂 Давай сначала немного познакомимся здесь."
                                testInput.contains("привет", ignoreCase = true) -> "Привет! А что тебя сегодня привело ко мне?"
                                else -> "Интересно! Расскажешь немного подробнее?"
                            }
                        })
                        OutlineButton("Изменить характер", { go(Page.PERSONA) })
                        OutlineButton("На главный экран", { go(Page.HOME) })
                    }
                    Page.TELEGRAM -> {
                        Headline("Telegram Business", "Этот прототип показывает подключение, но не запрашивает доступ к твоему аккаунту.")
                        AuroraCard {
                            Text("① Создай своего двойника", fontWeight = FontWeight.SemiBold)
                            Text("Проверь стиль и ограничения", color = Aura.secondary)
                            HorizontalDivider(color = Aura.border)
                            Text("② Подключи официальный Business-бот", fontWeight = FontWeight.SemiBold)
                            Text("В реальном продукте — через настройки Telegram Business", color = Aura.secondary)
                            HorizontalDivider(color = Aura.border)
                            Text("③ Выбери чаты", fontWeight = FontWeight.SemiBold)
                            Text("Новые личные диалоги или только выбранные контакты", color = Aura.secondary)
                        }
                        TextTag("НЕ ПОДКЛЮЧЕНО", Aura.orange)
                        OutlineButton("Вернуться к демонстрации", { go(Page.HOME) })
                        Footnote("Реальный webhook и авторизация Business пока отсутствуют — это план интеграции, не активная функция.")
                    }
                    Page.MEMORY -> {
                        Headline("Память двойника", "Это пока иллюстрация устройства будущей памяти.")
                        AuroraHero(height = 145.dp, animate = movement)
                        AuroraCard {
                            Text("Манера общения", fontWeight = FontWeight.SemiBold)
                            Text("$voice · $humor", color = Aura.secondary)
                        }
                        AuroraCard {
                            Text("Границы", fontWeight = FontWeight.SemiBold)
                            Text(boundaries, color = Aura.secondary)
                        }
                        Footnote("Нет хранения реальных собеседников или переписок в этом демо.")
                    }
                    Page.SETTINGS -> {
                        Headline("Настройки", "Здесь всё, что должно быть под твоим контролем.")
                        AuroraCard {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("Живое свечение", fontWeight = FontWeight.SemiBold)
                                    Text("Частицы, мягкие волны и подсветка", color = Aura.secondary, fontSize = 12.sp)
                                }
                                Switch(movement, { movement = it })
                            }
                        }
                        ChoiceCard("Защита переписок", "Проверка импорта перед использованием", "◈") { go(Page.UPLOAD) }
                        ChoiceCard("Подключение Telegram", "Статус: не подключён", "✈") { go(Page.TELEGRAM) }
                        ChoiceCard("Изменить личность", "Настройки характера и границ", "✦") { go(Page.PERSONA) }
                        Footnote("Автопилот и прочие данные этого прототипа — только внутри запущенной демонстрации.")
                    }
                    Page.CONTACT -> {
                        Headline(activeChat, "Переписка · демонстрационные данные")
                        AuroraCard {
                            Text(activeChat, fontWeight = FontWeight.SemiBold, color = Aura.secondary)
                            Text("Привет! Давай увидимся в выходные?")
                        }
                        AuroraCard {
                            Text("Предложение двойника", color = Aura.violet, fontWeight = FontWeight.SemiBold)
                            Text(proposal)
                        }
                        MainButton("Посмотреть и решить", { go(Page.REVIEW) })
                        OutlineButton("К списку диалогов", { go(Page.DIALOGS) })
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
        if (page in listOf(Page.HOME, Page.DIALOGS, Page.PERSONA, Page.SETTINGS)) {
            Row(Modifier.fillMaxWidth().background(Aura.deep).border(BorderStroke(1.dp, Aura.border.copy(alpha=.4f)))
                .navigationBarsPadding().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                listOf(
                    Triple(Page.HOME, "Сегодня", Icons.Default.Home),
                    Triple(Page.DIALOGS, "Диалоги", Icons.Default.Chat),
                    Triple(Page.PERSONA, "Двойник", Icons.Default.Face),
                    Triple(Page.SETTINGS, "Ещё", Icons.Default.Settings)
                ).forEach { (target, label, icon) ->
                    NavigationBarItem(selected = page == target, onClick = { go(target) }, modifier = Modifier.weight(1f),
                        icon = { Icon(icon, label, modifier = Modifier.size(21.dp)) },
                        label = { Text(label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Aura.mint,
                            selectedTextColor = Aura.mint, indicatorColor = Aura.raised,
                            unselectedIconColor = Aura.muted, unselectedTextColor = Aura.muted),
                        alwaysShowLabel = true)
                }
            }
        }
    }
}

@Composable private fun AuroraInput(value: String, onChange: (String) -> Unit, hint: String, lines: Int = 2) {
    OutlinedTextField(value = value, onValueChange = onChange, modifier = Modifier.fillMaxWidth(),
        placeholder = { Text(hint, color = Aura.muted) }, minLines = lines, maxLines = 5,
        shape = RoundedCornerShape(14.dp), colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Aura.white, unfocusedTextColor = Aura.white,
            focusedBorderColor = Aura.mint, unfocusedBorderColor = Aura.border,
            cursorColor = Aura.mint, focusedContainerColor = Aura.deep, unfocusedContainerColor = Aura.deep))
}

@Composable private fun ChoiceCard(title: String, subtitle: String, badge: String, onClick: () -> Unit) {
    AuroraCard(modifier = Modifier.clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)).background(Aura.violet.copy(alpha = .14f)),
                contentAlignment = Alignment.Center) { Text(badge, color = Aura.mint, fontSize = 23.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Aura.white, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Aura.secondary, fontSize = 12.sp, lineHeight = 17.sp)
            }
            Icon(Icons.AutoMirrored.Filled.ArrowForward, null, tint = Aura.muted, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable private fun PillRow(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { v ->
            val active = selected == v
            Box(Modifier.clip(RoundedCornerShape(100.dp))
                .background(if (active) Aura.mint.copy(alpha = .17f) else Aura.raised)
                .border(1.dp, if (active) Aura.mint else Aura.border, RoundedCornerShape(100.dp))
                .clickable { onSelect(v) }.padding(horizontal = 14.dp, vertical = 11.dp)) {
                Text(v, color = if (active) Aura.mint else Aura.secondary, fontSize = 13.sp)
            }
        }
    }
}

@Composable private fun MiniMetric(number: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(17.dp)).background(Aura.surface)
        .border(1.dp, Aura.border.copy(alpha=.6f), RoundedCornerShape(17.dp)).padding(14.dp)) {
        Text(number, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Aura.white)
        Text(label, fontSize = 11.sp, color = Aura.secondary)
    }
}

@Composable private fun ChatItem(chat: DemoChat, onClick: () -> Unit) {
    AuroraCard(modifier = Modifier.clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Aura.raised, CircleShape), contentAlignment = Alignment.Center) {
                Text(chat.name.take(1), color = Aura.cyan, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(chat.name, fontWeight = FontWeight.Bold, color = Aura.white,
                        modifier = Modifier.weight(1f))
                    Text(chat.time, fontSize = 11.sp, color = Aura.muted)
                }
                Text(chat.snippet, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    fontSize = 13.sp, color = Aura.secondary)
                Spacer(Modifier.height(4.dp))
                TextTag(chat.state, if (chat.state == "Нужно решение") Aura.orange else Aura.mint)
            }
        }
    }
}

@Composable private fun Footnote(text: String) {
    Text(text, color = Aura.muted, fontSize = 12.sp, lineHeight = 18.sp)
}
