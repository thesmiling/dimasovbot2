package ru.aurora.twin
import org.junit.Assert.*
import org.junit.Test

class PrivacyScannerTest {
    @Test fun luhnMatchesKnownTestVector() {
        assertTrue(PrivacyScanner.luhn("4111111111111111"))
        assertFalse(PrivacyScanner.luhn("4111111111111112"))
    }
    @Test fun redactsSecretsFromPreview() {
        val report = PrivacyScanner.scan("Пароль: qwerty123\nКод из смс 483921\nemail a@example.com\nкарта 4111 1111 1111 1111")
        assertFalse(report.sanitizedPreview.contains("qwerty123"))
        assertFalse(report.sanitizedPreview.contains("483921"))
        assertFalse(report.sanitizedPreview.contains("a@example.com"))
        assertFalse(report.sanitizedPreview.contains("4111 1111 1111 1111"))
        assertTrue(report.total >= 4)
    }
    @Test fun sensitiveSubjectLineIsExcluded() {
        val report = PrivacyScanner.scan("Обычное сообщение\nмедицинский диагноз\nЕщё сообщение")
        assertFalse(report.sanitizedPreview.contains("диагноз"))
        assertTrue(report.sanitizedPreview.contains("[ТЕМА ИСКЛЮЧЕНА]"))
    }
}
